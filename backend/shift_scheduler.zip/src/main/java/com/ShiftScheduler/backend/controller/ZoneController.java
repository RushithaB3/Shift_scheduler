package com.shiftscheduler.backend.controller;

import com.shiftscheduler.backend.model.Zone;
import com.shiftscheduler.backend.repository.ZoneRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/zones")
public class ZoneController {

    private final ZoneRepository zoneRepository;

    public ZoneController(ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }

    // Display all zones and zone form
    @GetMapping
    public String showZones(Model model) {
        model.addAttribute("zones", zoneRepository.findAll());
        model.addAttribute("zoneForm", new Zone());
        return "zones";
    }

    // Save new or updated zone
    @PostMapping("/save")
    public String saveZone(@ModelAttribute("zoneForm") Zone zone) {
        zoneRepository.save(zone);
        return "redirect:/zones";
    }

    // Load existing zone for editing
    @GetMapping("/edit/{id}")
    public String editZone(@PathVariable Long id, Model model) {
        Optional<Zone> zone = zoneRepository.findById(id);
        model.addAttribute("zoneForm", zone.orElse(new Zone()));
        model.addAttribute("zones", zoneRepository.findAll());
        return "zones";
    }

    // Delete zone by ID
    @GetMapping("/delete/{id}")
    public String deleteZone(@PathVariable Long id) {
        zoneRepository.deleteById(id);
        return "redirect:/zones";
    }
}
