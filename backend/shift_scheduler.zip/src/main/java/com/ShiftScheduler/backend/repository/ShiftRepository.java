package com.shiftscheduler.backend.repository;

import com.shiftscheduler.backend.model.Shift;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ShiftRepository extends JpaRepository<Shift, Long> {

    // Find all shifts for a specific user
    List<Shift> findByUserId(Long userId);

    // Find shifts by zone and zip code names (if needed for string-based filtering)
    List<Shift> findByZone_NameAndZipCode_Code(String zoneName, String zipCode);

    // Find shifts that overlap with the selected date range and location
    List<Shift> findByZone_IdAndZipCode_IdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
        Long zoneId,
        Long zipCodeId,
        LocalDate endDate,
        LocalDate startDate
    );
}
